package com.example.skylink.objects.Interfaces;

public interface iAircraft {
    String getName();

    void setName(String name);

    int getNumSeatPerRowBusiness();

    void setNumSeatPerRowBusiness(int numSeatPerRowBusiness);

    int getNumRowsBusiness();

    void setNumRowsBusiness(int numRowsBusiness);

    int getNumSeatPerRowEcon();

    void setNumSeatPerRowEcon(int numSeatPerRowEcon);

    int getNumRowsEcon();

    void setNumRowsEcon(int numRowsEcon);
}
