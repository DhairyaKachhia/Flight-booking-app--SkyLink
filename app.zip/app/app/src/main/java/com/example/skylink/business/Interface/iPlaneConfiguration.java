package com.example.skylink.business.Interface;

public interface iPlaneConfiguration {
    String[] getPlaneConfiguration(String airCraftName, String econOrBus);
}
