package com.example.skylink.objects.Interfaces;

public interface iCity {
    // Getter methods
    String getName();
    String getCode();

    // toString method
    String toString();
}
